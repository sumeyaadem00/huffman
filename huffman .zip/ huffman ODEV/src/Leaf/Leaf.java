package Leaf;

import lombok.RequiredArgsConstructor;
import odev.Node;



public class Leaf extends Node {
    private final char character;

    public Leaf(char character, int frequency) {
        super(frequency);
        this.character = character;
    }

}

