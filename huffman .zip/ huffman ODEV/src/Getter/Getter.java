package Getter;

public @interface Getter {
}
