package Node;

import java.util.Map;

public class Node {
    private int frequency;
    private Node leftNode;
    private Node rightNode;

    public Node(Node leftNode, Node rightNode) {
        this.leftNode=leftNode;
        this.rightNode=rightNode;
        this.frequency = leftNode.getFrequency() + rightNode.getFrequency();

    }

    public Node(Map<Character, Integer> charFrequencies) {
    }

    public Node(Object character, Integer frequency) {
    }


    public Node getLeftNode() {
        return leftNode;
    }

    public char getFrequency() {
        return (char) frequency;
    }

    public void setFrequency(char frequency) {
        this.frequency =frequency;
    }


    public Node getRightNode() {
        return rightNode;
    }

    public void setRightNode(Node rightNode) {
        this.rightNode=rightNode;
    }
}





