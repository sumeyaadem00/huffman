package odev;

public class Node {
    int frequency;
    Node leftNode;
    Node rightNode;

    public Node(Node leftNode, Node rightNode) {
        this.leftNode = leftNode;
        this.rightNode = rightNode;
        this.frequency = leftNode.getFrequency() + rightNode.getFrequency();
    }

    public Node(int frequency) {
    }


    public int compareTo(Node node)
    {
        return Integer.compare(frequency, node.getFrequency());
    }


    public Node getLeftNode() {
        return leftNode;
    }

    public void setLeftNode(Node leftNode) {
        this.leftNode=leftNode;
    }

    Node getRightNode() {
        return rightNode;
    }

    private void setRightNode(Node rightNode) {
        this.rightNode=rightNode;
    }


    public int getFrequency() {
        return frequency;
    }

    public static Character getCharacter() {
        Character character=null;
        return character;
    }



}

