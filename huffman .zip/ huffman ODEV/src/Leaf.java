public class Leaf {
    private final char character;

    public Leaf(char character, int frequency) {
        super();
        this.character = character;
    }

}

